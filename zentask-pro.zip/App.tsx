
import React, { useState, useEffect, useCallback } from 'react';
import { Priority, Recurrence, Task, ViewType, UserStats } from './types';
import Sidebar from './components/Sidebar';
import Navbar from './components/Navbar';
import TaskList from './components/TaskList';
import Dashboard from './components/Dashboard';
import CalendarView from './components/CalendarView';
import LoginModal from './components/LoginModal';
import NotificationManager from './components/NotificationManager';

const App: React.FC = () => {
  const [username, setUsername] = useState<string | null>(localStorage.getItem('zen_username'));
  const [isDarkMode, setIsDarkMode] = useState<boolean>(localStorage.getItem('zen_theme') === 'dark');
  const [currentView, setCurrentView] = useState<ViewType>('Home');
  const [tasks, setTasks] = useState<Task[]>([]);
  const [stats, setStats] = useState<UserStats>({ streak: 0, lastActiveDate: null });

  // Load data on mount or user change
  useEffect(() => {
    if (username) {
      const storedTasks = localStorage.getItem(`tasks_${username}`);
      const storedStats = localStorage.getItem(`stats_${username}`);
      
      if (storedTasks) setTasks(JSON.parse(storedTasks));
      if (storedStats) setStats(JSON.parse(storedStats));
    }
  }, [username]);

  // Save tasks whenever they change
  useEffect(() => {
    if (username) {
      localStorage.setItem(`tasks_${username}`, JSON.stringify(tasks));
      updateStreak();
    }
  }, [tasks, username]);

  // Apply dark mode
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('zen_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('zen_theme', 'light');
    }
  }, [isDarkMode]);

  const updateStreak = useCallback(() => {
    if (!username) return;
    const today = new Date().toISOString().split('T')[0];
    const lastActive = stats.lastActiveDate;

    // Logic: If all tasks for yesterday were completed, increment streak.
    // Simplified for this demo: If at least one task was completed today, and it's a new day, update streak.
    const completedToday = tasks.some(t => t.completed && t.completedAt?.startsWith(today));
    
    if (completedToday && lastActive !== today) {
      let newStreak = stats.streak;
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const yesterdayStr = yesterday.toISOString().split('T')[0];

      if (lastActive === yesterdayStr) {
        newStreak += 1;
      } else if (lastActive === null || lastActive < yesterdayStr) {
        newStreak = 1;
      }

      const newStats = { streak: newStreak, lastActiveDate: today };
      setStats(newStats);
      localStorage.setItem(`stats_${username}`, JSON.stringify(newStats));
    }
  }, [tasks, stats, username]);

  const addTask = (task: Omit<Task, 'id' | 'createdAt' | 'completed'>) => {
    const newTask: Task = {
      ...task,
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString(),
      completed: false,
    };
    setTasks(prev => [newTask, ...prev]);
  };

  const toggleTask = (id: string) => {
    setTasks(prev => prev.map(t => 
      t.id === id ? { 
        ...t, 
        completed: !t.completed, 
        completedAt: !t.completed ? new Date().toISOString() : undefined 
      } : t
    ));
  };

  const deleteTask = (id: string) => {
    setTasks(prev => prev.filter(t => t.id !== id));
  };

  const handleLogin = (name: string) => {
    setUsername(name);
    localStorage.setItem('zen_username', name);
  };

  const logout = () => {
    setUsername(null);
    localStorage.removeItem('zen_username');
    setTasks([]);
  };

  const filteredTasks = tasks.filter(task => {
    const today = new Date().toISOString().split('T')[0];
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayStr = yesterday.toISOString().split('T')[0];

    switch (currentView) {
      case 'Today':
        return task.dueDate.startsWith(today);
      case 'Yesterday':
        return task.dueDate.startsWith(yesterdayStr);
      case 'DailyRoutine':
        return task.recurrence !== Recurrence.NONE;
      case 'Important':
        return task.priority === Priority.HIGH;
      case 'Study':
      case 'Office':
      case 'Personal':
        return task.category === currentView;
      case 'Home':
      default:
        return true;
    }
  });

  if (!username) {
    return <LoginModal onLogin={handleLogin} />;
  }

  return (
    <div className="flex flex-col md:flex-row min-h-screen">
      <Sidebar currentView={currentView} setView={setCurrentView} />
      
      <main className="flex-1 flex flex-col min-w-0 bg-slate-50 dark:bg-slate-900 transition-colors">
        <Navbar 
          username={username} 
          isDarkMode={isDarkMode} 
          toggleDarkMode={() => setIsDarkMode(!isDarkMode)} 
          logout={logout}
        />

        <div className="p-4 md:p-8 flex-1 overflow-y-auto">
          <NotificationManager tasks={tasks} />
          
          {currentView === 'Profile' ? (
            <Dashboard tasks={tasks} stats={stats} username={username} setTasks={setTasks} />
          ) : currentView === 'Calendar' ? (
            <CalendarView tasks={tasks} onToggleTask={toggleTask} />
          ) : (
            <div className="max-w-4xl mx-auto space-y-6">
              <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-2">
                <div>
                  <h1 className="text-3xl font-bold text-slate-900 dark:text-white">{currentView} Tasks</h1>
                  <p className="text-slate-500 dark:text-slate-400">Organize your workflow effectively.</p>
                </div>
              </header>

              <TaskList 
                tasks={filteredTasks} 
                onToggle={toggleTask} 
                onDelete={deleteTask} 
                onAdd={addTask}
                view={currentView}
              />
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default App;
