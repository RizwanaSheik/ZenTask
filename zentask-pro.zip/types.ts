
export enum Priority {
  HIGH = 'High',
  MEDIUM = 'Medium',
  LOW = 'Low'
}

export enum Recurrence {
  NONE = 'None',
  DAILY = 'Daily',
  WEEKLY = 'Weekly',
  MONTHLY = 'Monthly'
}

export interface Task {
  id: string;
  title: string;
  category: string;
  priority: Priority;
  dueDate: string; // ISO string
  completed: boolean;
  tags: string[];
  recurrence: Recurrence;
  createdAt: string;
  completedAt?: string;
}

export type ViewType = 
  | 'Home' 
  | 'Today' 
  | 'Yesterday' 
  | 'DailyRoutine' 
  | 'Profile' 
  | 'Calendar' 
  | 'Study' 
  | 'Office' 
  | 'Personal' 
  | 'Important';

export interface UserStats {
  streak: number;
  lastActiveDate: string | null;
}
