
import React from 'react';
import { Task, UserStats, Priority } from '../types';
import { 
  Download, 
  Upload, 
  Flame, 
  CheckCircle, 
  Clock, 
  AlertTriangle, 
  BarChart3,
  TrendingUp,
  FileJson
} from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';

interface DashboardProps {
  tasks: Task[];
  stats: UserStats;
  username: string;
  setTasks: (tasks: Task[]) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ tasks, stats, username, setTasks }) => {
  const today = new Date().toISOString().split('T')[0];
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const tomorrowStr = tomorrow.toISOString().split('T')[0];

  const todayTasks = tasks.filter(t => t.dueDate.startsWith(today));
  const completedToday = todayTasks.filter(t => t.completed);
  const missedToday = todayTasks.filter(t => !t.completed && new Date(t.dueDate) < new Date());
  const dueTomorrow = tasks.filter(t => t.dueDate.startsWith(tomorrowStr));

  const completionRate = todayTasks.length > 0 
    ? Math.round((completedToday.length / todayTasks.length) * 100) 
    : 0;

  const data = [
    { name: 'Completed', value: completedToday.length, color: '#6366f1' },
    { name: 'Pending', value: todayTasks.length - completedToday.length, color: '#e2e8f0' }
  ];

  const handleExport = () => {
    const dataStr = JSON.stringify(tasks, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `zentask_${username}_${today}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const importedTasks = JSON.parse(event.target?.result as string);
        if (Array.isArray(importedTasks)) {
          setTasks([...tasks, ...importedTasks]);
          alert('Tasks imported successfully!');
        }
      } catch (err) {
        alert('Invalid JSON file format.');
      }
    };
    reader.readAsText(file);
  };

  const StatCard = ({ icon, label, val, sub, color }: any) => (
    <div className="bg-white dark:bg-slate-950 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
      <div className="flex justify-between items-start mb-4">
        <div className={`p-3 rounded-xl ${color}`}>
          {icon}
        </div>
        <div className="flex items-center gap-1 text-green-500 font-bold text-sm">
           <TrendingUp size={14} />
           <span>Live</span>
        </div>
      </div>
      <p className="text-slate-500 dark:text-slate-400 font-medium text-sm">{label}</p>
      <h4 className="text-3xl font-bold mt-1">{val}</h4>
      <p className="text-xs text-slate-400 mt-2">{sub}</p>
    </div>
  );

  return (
    <div className="max-w-6xl mx-auto space-y-8 pb-12">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-4xl font-black text-slate-900 dark:text-white">Productivity Dashboard</h1>
          <p className="text-slate-500 mt-1">Hello {username}, here's your performance overview.</p>
        </div>
        
        <div className="flex gap-3">
          <button 
            onClick={handleExport}
            className="flex items-center gap-2 px-4 py-2 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl font-semibold shadow-sm hover:bg-slate-50 dark:hover:bg-slate-900 transition-colors"
          >
            <Download size={18} />
            Export
          </button>
          <label className="flex items-center gap-2 px-4 py-2 bg-primary text-white rounded-xl font-semibold shadow-lg shadow-primary/30 cursor-pointer hover:bg-primary/90 transition-colors">
            <Upload size={18} />
            Import
            <input type="file" className="hidden" accept=".json" onChange={handleImport} />
          </label>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          icon={<BarChart3 size={24} />} 
          label="Total Today" 
          val={todayTasks.length} 
          sub="Tasks scheduled" 
          color="bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400"
        />
        <StatCard 
          icon={<CheckCircle size={24} />} 
          label="Completed" 
          val={completedToday.length} 
          sub={`${completionRate}% Completion Rate`} 
          color="bg-green-50 dark:bg-green-900/30 text-green-600 dark:text-green-400"
        />
        <StatCard 
          icon={<AlertTriangle size={24} />} 
          label="Missed" 
          val={missedToday.length} 
          sub="Overdue tasks" 
          color="bg-red-50 dark:bg-red-900/30 text-red-600 dark:text-red-400"
        />
        <StatCard 
          icon={<Clock size={24} />} 
          label="Due Tomorrow" 
          val={dueTomorrow.length} 
          sub="Plan ahead" 
          color="bg-purple-50 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-white dark:bg-slate-950 p-8 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row gap-8 items-center">
          <div className="w-full md:w-1/2 space-y-6">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-orange-100 dark:bg-orange-950/30 rounded-2xl flex items-center justify-center text-orange-600">
                  <Flame size={28} />
                </div>
                <div>
                  <h3 className="text-xl font-bold">Productivity Streak</h3>
                  <p className="text-slate-500 text-sm">Consistent action pays off!</p>
                </div>
              </div>
              <div className="flex items-end gap-2">
                <span className="text-6xl font-black text-orange-500">{stats.streak}</span>
                <span className="text-xl font-bold text-slate-400 mb-2">Days</span>
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between text-sm font-bold">
                <span>Daily Completion</span>
                <span>{completionRate}%</span>
              </div>
              <div className="w-full h-3 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-primary transition-all duration-1000 ease-out" 
                  style={{ width: `${completionRate}%` }}
                />
              </div>
            </div>
          </div>

          <div className="w-full md:w-1/2 h-[250px] relative">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={data}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {data.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-center">
              <span className="text-2xl font-bold block">{completedToday.length}</span>
              <span className="text-xs text-slate-400 uppercase font-bold tracking-widest">Done</span>
            </div>
          </div>
        </div>

        <div className="bg-primary text-white p-8 rounded-3xl shadow-2xl shadow-primary/20 flex flex-col justify-between">
           <div>
              <h3 className="text-2xl font-bold mb-4">Level Up!</h3>
              <p className="opacity-80 leading-relaxed mb-6">
                Keep completing your daily tasks to unlock new themes and productivity badges. You're in the top 10% of users this week.
              </p>
           </div>
           <div className="space-y-4">
              <div className="bg-white/20 p-4 rounded-2xl backdrop-blur-md flex items-center gap-4">
                <FileJson size={32} />
                <div>
                  <p className="text-xs font-bold opacity-70 uppercase tracking-tighter">Backup Status</p>
                  <p className="font-medium">Automatic cloud sync</p>
                </div>
              </div>
              <button className="w-full py-4 bg-white text-primary font-black rounded-2xl hover:scale-105 transition-transform">
                VIEW LEADERBOARD
              </button>
           </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
