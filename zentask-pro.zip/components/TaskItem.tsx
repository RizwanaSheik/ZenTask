
import React from 'react';
import { Task, Priority, Recurrence } from '../types';
import { Trash2, CheckCircle, Circle, Calendar, Tag, Repeat } from 'lucide-react';

interface TaskItemProps {
  task: Task;
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
}

const TaskItem: React.FC<TaskItemProps> = ({ task, onToggle, onDelete }) => {
  const priorityColors = {
    [Priority.HIGH]: 'border-l-red-500 bg-red-50/30 dark:bg-red-950/10 text-red-600',
    [Priority.MEDIUM]: 'border-l-yellow-500 bg-yellow-50/30 dark:bg-yellow-950/10 text-yellow-600',
    [Priority.LOW]: 'border-l-green-500 bg-green-50/30 dark:bg-green-950/10 text-green-600',
  };

  const badgeColors = {
    [Priority.HIGH]: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400',
    [Priority.MEDIUM]: 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400',
    [Priority.LOW]: 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400',
  };

  return (
    <div className={`group flex items-center gap-4 p-5 rounded-2xl bg-white dark:bg-slate-950 border-l-4 ${priorityColors[task.priority]} border-y border-r border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition-all`}>
      <button 
        onClick={() => onToggle(task.id)}
        className="flex-shrink-0 transition-transform active:scale-90"
      >
        {task.completed ? (
          <CheckCircle className="text-primary" size={24} />
        ) : (
          <Circle className="text-slate-300 dark:text-slate-700" size={24} />
        )}
      </button>

      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-1">
          <h3 className={`text-lg font-semibold truncate ${task.completed ? 'line-through text-slate-400' : 'text-slate-800 dark:text-slate-100'}`}>
            {task.title}
          </h3>
          <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full ${badgeColors[task.priority]}`}>
            {task.priority}
          </span>
        </div>

        <div className="flex flex-wrap gap-4 text-sm text-slate-500 dark:text-slate-400">
          <div className="flex items-center gap-1.5">
            <Calendar size={14} />
            <span>{new Date(task.dueDate).toLocaleDateString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</span>
          </div>
          
          {task.recurrence !== Recurrence.NONE && (
            <div className="flex items-center gap-1.5">
              <Repeat size={14} />
              <span>{task.recurrence}</span>
            </div>
          )}

          {task.tags.length > 0 && (
            <div className="flex items-center gap-1.5">
              <Tag size={14} />
              <div className="flex gap-1">
                {task.tags.map(tag => (
                  <span key={tag} className="text-xs bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-md">#{tag}</span>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      <button 
        onClick={() => onDelete(task.id)}
        className="opacity-0 group-hover:opacity-100 p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30 rounded-lg transition-all"
        title="Delete Task"
      >
        <Trash2 size={20} />
      </button>
    </div>
  );
};

export default TaskItem;
