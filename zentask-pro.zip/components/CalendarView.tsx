
import React, { useState } from 'react';
import { Task } from '../types';
import { ChevronLeft, ChevronRight, Calendar as CalendarIcon } from 'lucide-react';
import TaskItem from './TaskItem';

interface CalendarViewProps {
  tasks: Task[];
  onToggleTask: (id: string) => void;
}

const CalendarView: React.FC<CalendarViewProps> = ({ tasks, onToggleTask }) => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString().split('T')[0]);

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const firstDayOfMonth = new Date(year, month, 1).getDay();

  const days = Array.from({ length: daysInMonth }, (_, i) => i + 1);
  const padding = Array.from({ length: firstDayOfMonth }, (_, i) => null);

  const prevMonth = () => setCurrentDate(new Date(year, month - 1, 1));
  const nextMonth = () => setCurrentDate(new Date(year, month + 1, 1));

  const monthName = currentDate.toLocaleString('default', { month: 'long' });

  const tasksOnSelectedDate = tasks.filter(t => t.dueDate.startsWith(selectedDate));

  const getDots = (day: number) => {
    const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    const dayTasks = tasks.filter(t => t.dueDate.startsWith(dateStr));
    if (dayTasks.length === 0) return null;
    return (
      <div className="flex gap-0.5 justify-center mt-1">
        {dayTasks.slice(0, 3).map((t, i) => (
          <div key={i} className={`w-1 h-1 rounded-full ${t.completed ? 'bg-slate-400' : 'bg-primary'}`} />
        ))}
        {dayTasks.length > 3 && <div className="w-1 h-1 rounded-full bg-slate-400" />}
      </div>
    );
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="bg-white dark:bg-slate-950 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
        <header className="p-6 bg-slate-50 dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
             <CalendarIcon className="text-primary" />
             <h2 className="text-xl font-bold">{monthName} {year}</h2>
          </div>
          <div className="flex gap-2">
            <button onClick={prevMonth} className="p-2 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-lg"><ChevronLeft /></button>
            <button onClick={nextMonth} className="p-2 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-lg"><ChevronRight /></button>
          </div>
        </header>

        <div className="p-6">
          <div className="grid grid-cols-7 gap-1 mb-4">
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(d => (
              <div key={d} className="text-center text-xs font-bold text-slate-400 uppercase py-2">{d}</div>
            ))}
            
            {padding.map((_, i) => <div key={`p-${i}`} className="h-16 md:h-24" />)}
            
            {days.map(day => {
              const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
              const isSelected = selectedDate === dateStr;
              const isToday = new Date().toISOString().split('T')[0] === dateStr;

              return (
                <button
                  key={day}
                  onClick={() => setSelectedDate(dateStr)}
                  className={`h-16 md:h-24 rounded-2xl flex flex-col items-center justify-center transition-all ${
                    isSelected 
                      ? 'bg-primary text-white shadow-lg scale-105 z-10' 
                      : isToday 
                        ? 'bg-primary/10 text-primary font-black border border-primary/20'
                        : 'hover:bg-slate-50 dark:hover:bg-slate-900'
                  }`}
                >
                  <span className="text-lg font-bold">{day}</span>
                  {getDots(day)}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-xl font-bold">Tasks for {new Date(selectedDate).toLocaleDateString(undefined, { month: 'long', day: 'numeric', year: 'numeric' })}</h3>
          <span className="bg-slate-100 dark:bg-slate-800 px-3 py-1 rounded-full text-sm font-bold text-slate-500">{tasksOnSelectedDate.length} Tasks</span>
        </div>
        
        {tasksOnSelectedDate.length > 0 ? (
          tasksOnSelectedDate.map(task => (
            <TaskItem key={task.id} task={task} onToggle={onToggleTask} onDelete={() => {}} />
          ))
        ) : (
          <div className="p-12 text-center bg-white dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 opacity-50 italic">
            No tasks scheduled for this day.
          </div>
        )}
      </div>
    </div>
  );
};

export default CalendarView;
