
import React, { useState } from 'react';
import { UserPlus, Sparkles } from 'lucide-react';

interface LoginModalProps {
  onLogin: (username: string) => void;
}

const LoginModal: React.FC<LoginModalProps> = ({ onLogin }) => {
  const [name, setName] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim()) onLogin(name.trim());
  };

  return (
    <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-950 w-full max-w-md p-8 rounded-[40px] shadow-2xl space-y-8 animate-in zoom-in duration-300">
        <div className="text-center space-y-4">
          <div className="w-20 h-20 bg-primary/10 text-primary rounded-[30px] flex items-center justify-center mx-auto">
             <Sparkles size={40} />
          </div>
          <h1 className="text-4xl font-black text-slate-900 dark:text-white">Welcome to ZenTask</h1>
          <p className="text-slate-500">The minimalist way to maximize your productivity. Let's start by getting to know you.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-bold mb-2 text-slate-400 uppercase tracking-widest">Your Name</label>
            <input 
              autoFocus
              type="text" 
              placeholder="e.g. Rizwana"
              className="w-full px-6 py-4 rounded-2xl bg-slate-50 dark:bg-slate-900 border-2 border-slate-200 dark:border-slate-800 focus:border-primary outline-none text-xl transition-all"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>
          
          <button 
            type="submit"
            className="w-full py-5 bg-primary text-white text-lg font-black rounded-2xl shadow-xl shadow-primary/40 hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-3"
          >
            <UserPlus />
            GET STARTED
          </button>
        </form>

        <p className="text-center text-xs text-slate-400">
          Your data is stored locally in your browser. <br/> 
          We never upload your personal tasks to a server.
        </p>
      </div>
    </div>
  );
};

export default LoginModal;
