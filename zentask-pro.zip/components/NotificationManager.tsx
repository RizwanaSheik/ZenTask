
import React, { useEffect, useRef } from 'react';
import { Task } from '../types';

interface NotificationManagerProps {
  tasks: Task[];
}

const NotificationManager: React.FC<NotificationManagerProps> = ({ tasks }) => {
  const notifiedTasks = useRef<Set<string>>(new Set());

  useEffect(() => {
    // Request permission on mount
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission();
    }

    const checkDeadlines = () => {
      if (!('Notification' in window) || Notification.permission !== 'granted') return;

      const now = new Date();
      tasks.forEach(task => {
        if (task.completed) return;

        const dueDate = new Date(task.dueDate);
        const diffMs = dueDate.getTime() - now.getTime();
        const diffMins = Math.floor(diffMs / (1000 * 60));

        // If deadline is within next 30 minutes and not notified yet
        if (diffMins > 0 && diffMins <= 30 && !notifiedTasks.current.has(task.id)) {
          new Notification('⏳ Task Deadline Approaching', {
            body: `[${task.title}] is due in ${diffMins} minutes!`,
            icon: 'https://cdn-icons-png.flaticon.com/512/2098/2098402.png'
          });
          notifiedTasks.current.add(task.id);
        }
      });
    };

    const interval = setInterval(checkDeadlines, 60000); // Check every minute
    return () => clearInterval(interval);
  }, [tasks]);

  return null; // Invisible utility component
};

export default NotificationManager;
