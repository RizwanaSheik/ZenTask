
import React, { useState, useMemo } from 'react';
import { Task, Priority, ViewType } from '../types';
import TaskItem from './TaskItem';
import TaskForm from './TaskForm';
import { Search, Filter, Plus, ListFilter } from 'lucide-react';

interface TaskListProps {
  tasks: Task[];
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
  onAdd: (task: Omit<Task, 'id' | 'createdAt' | 'completed'>) => void;
  view: ViewType;
}

const TaskList: React.FC<TaskListProps> = ({ tasks, onToggle, onDelete, onAdd, view }) => {
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('All');
  const [showForm, setShowForm] = useState(false);

  const filteredAndSortedTasks = useMemo(() => {
    let result = tasks.filter(t => 
      t.title.toLowerCase().includes(search.toLowerCase()) ||
      t.tags.some(tag => tag.toLowerCase().includes(search.toLowerCase()))
    );

    if (filter === 'Completed') result = result.filter(t => t.completed);
    if (filter === 'Pending') result = result.filter(t => !t.completed);
    if (filter === 'High Priority') result = result.filter(t => t.priority === Priority.HIGH);

    return result.sort((a, b) => {
      if (a.completed !== b.completed) return a.completed ? 1 : -1;
      const priorityMap = { [Priority.HIGH]: 3, [Priority.MEDIUM]: 2, [Priority.LOW]: 1 };
      return priorityMap[b.priority] - priorityMap[a.priority];
    });
  }, [tasks, search, filter]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input 
            type="text" 
            placeholder="Search tasks or tags..."
            className="w-full pl-10 pr-4 py-3 rounded-xl bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        
        <div className="flex gap-2">
          <div className="relative">
            <ListFilter className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" size={18} />
            <select 
              className="pl-10 pr-8 py-3 rounded-xl bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 focus:outline-none appearance-none font-medium text-slate-600 dark:text-slate-300 cursor-pointer"
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
            >
              <option>All</option>
              <option>Completed</option>
              <option>Pending</option>
              <option>High Priority</option>
            </select>
          </div>
          
          <button 
            onClick={() => setShowForm(!showForm)}
            className="flex items-center gap-2 px-6 py-3 bg-primary text-white rounded-xl font-bold shadow-lg shadow-primary/30 hover:scale-[1.02] active:scale-95 transition-all"
          >
            <Plus size={20} />
            Add Task
          </button>
        </div>
      </div>

      {showForm && (
        <TaskForm 
          onAdd={(task) => { onAdd(task); setShowForm(false); }} 
          onCancel={() => setShowForm(false)}
          defaultCategory={view === 'Home' || view === 'Today' || view === 'Yesterday' ? 'Personal' : view}
        />
      )}

      <div className="grid gap-4">
        {filteredAndSortedTasks.length > 0 ? (
          filteredAndSortedTasks.map(task => (
            <TaskItem key={task.id} task={task} onToggle={onToggle} onDelete={onDelete} />
          ))
        ) : (
          <div className="py-20 flex flex-col items-center justify-center text-center opacity-50">
            <div className="w-16 h-16 bg-slate-200 dark:bg-slate-800 rounded-full flex items-center justify-center mb-4">
               <Filter size={32} className="text-slate-400" />
            </div>
            <p className="text-xl font-medium">No tasks found</p>
            <p className="text-sm">Try changing your filters or add a new task.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default TaskList;
