
import React from 'react';
import { ViewType } from '../types';
import { 
  Home, 
  Calendar, 
  User, 
  Clock, 
  CheckSquare, 
  AlertCircle, 
  Book, 
  Briefcase, 
  UserCircle,
  Repeat
} from 'lucide-react';

interface SidebarProps {
  currentView: ViewType;
  setView: (view: ViewType) => void;
}

// NavItem moved outside to follow best practices and typed as React.FC to resolve TS errors regarding the 'key' prop
interface NavItemProps {
  item: { id: string; icon: React.ReactNode; label: string };
  currentView: ViewType;
  setView: (view: ViewType) => void;
}

const NavItem: React.FC<NavItemProps> = ({ item, currentView, setView }) => (
  <button
    onClick={() => setView(item.id as ViewType)}
    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
      currentView === item.id 
        ? 'bg-primary text-white shadow-lg shadow-primary/30' 
        : 'text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-800'
    }`}
  >
    {item.icon}
    <span className="font-medium">{item.label}</span>
  </button>
);

const Sidebar: React.FC<SidebarProps> = ({ currentView, setView }) => {
  const menuItems = [
    { id: 'Home', icon: <Home size={20}/>, label: 'Home' },
    { id: 'Today', icon: <Clock size={20}/>, label: 'Today' },
    { id: 'Yesterday', icon: <CheckSquare size={20}/>, label: 'Yesterday' },
    { id: 'DailyRoutine', icon: <Repeat size={20}/>, label: 'Daily Routine' },
    { id: 'Calendar', icon: <Calendar size={20}/>, label: 'Calendar' },
  ];

  const categories = [
    { id: 'Study', icon: <Book size={20}/>, label: 'Study' },
    { id: 'Office', icon: <Briefcase size={20}/>, label: 'Office' },
    { id: 'Personal', icon: <UserCircle size={20}/>, label: 'Personal' },
    { id: 'Important', icon: <AlertCircle size={20}/>, label: 'Important' },
    { id: 'Profile', icon: <User size={20}/>, label: 'Dashboard' },
  ];

  return (
    <aside className="w-full md:w-64 bg-white dark:bg-slate-950 border-r border-slate-200 dark:border-slate-800 p-6 flex flex-col gap-8">
      <div className="flex items-center gap-3 px-2">
        <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center text-white shadow-lg">
          <CheckSquare size={24} />
        </div>
        <span className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">ZenTask</span>
      </div>

      <nav className="flex flex-col gap-2">
        <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider px-4 mb-2">Main Menu</p>
        {menuItems.map(item => (
          <NavItem 
            key={item.id} 
            item={item} 
            currentView={currentView} 
            setView={setView} 
          />
        ))}
      </nav>

      <nav className="flex flex-col gap-2">
        <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider px-4 mb-2">Categories</p>
        {categories.map(item => (
          <NavItem 
            key={item.id} 
            item={item} 
            currentView={currentView} 
            setView={setView} 
          />
        ))}
      </nav>
      
      <div className="mt-auto pt-6 border-t border-slate-200 dark:border-slate-800">
        <div className="bg-slate-100 dark:bg-slate-900 rounded-xl p-4">
          <p className="text-sm font-medium text-slate-600 dark:text-slate-400">Pro Tip</p>
          <p className="text-xs text-slate-500 dark:text-slate-500 mt-1">Check your calendar to see task density for the month!</p>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
