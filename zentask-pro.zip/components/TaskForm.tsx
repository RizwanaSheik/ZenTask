
import React, { useState, useEffect } from 'react';
import { Priority, Recurrence } from '../types';
import { X, Sparkles, Tag as TagIcon, Plus } from 'lucide-react';

interface TaskFormProps {
  onAdd: (task: any) => void;
  onCancel: () => void;
  defaultCategory: string;
}

const TaskForm: React.FC<TaskFormProps> = ({ onAdd, onCancel, defaultCategory }) => {
  const [title, setTitle] = useState('');
  const [priority, setPriority] = useState<Priority>(Priority.MEDIUM);
  const [category, setCategory] = useState(defaultCategory || 'Personal');
  const [recurrence, setRecurrence] = useState<Recurrence>(Recurrence.NONE);
  const [dueDate, setDueDate] = useState(new Date().toISOString().slice(0, 16));
  const [tagInput, setTagInput] = useState('');
  const [tags, setTags] = useState<string[]>([]);
  const [suggestion, setSuggestion] = useState<string | null>(null);

  useEffect(() => {
    // Smart suggestions logic
    const lowerTitle = title.toLowerCase();
    if (lowerTitle.includes('exam')) {
      setSuggestion('Adding "Revision" task 2 days before?');
    } else if (lowerTitle.includes('meeting')) {
      setSuggestion('Remind 1 hour before?');
    } else {
      setSuggestion(null);
    }
  }, [title]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    onAdd({
      title,
      priority,
      category,
      recurrence,
      dueDate: new Date(dueDate).toISOString(),
      tags,
    });
  };

  const handleAddTag = (e?: React.KeyboardEvent) => {
    if (e && e.key !== 'Enter') return;
    if (e) e.preventDefault();
    if (tagInput.trim() && !tags.includes(tagInput.trim())) {
      setTags([...tags, tagInput.trim().replace('#', '')]);
      setTagInput('');
    }
  };

  const removeTag = (t: string) => setTags(tags.filter(tag => tag !== t));

  return (
    <div className="bg-white dark:bg-slate-950 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xl space-y-4 animate-in fade-in zoom-in duration-200">
      <div className="flex justify-between items-center mb-2">
        <h3 className="text-xl font-bold">New Task</h3>
        <button onClick={onCancel} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg">
          <X size={20} />
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-semibold mb-1 text-slate-500">Title</label>
          <input 
            autoFocus
            type="text" 
            placeholder="What needs to be done?"
            className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-transparent focus:ring-2 focus:ring-primary outline-none text-lg"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
        </div>

        {suggestion && (
          <div className="p-3 bg-indigo-50 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900/50 rounded-xl flex items-center justify-between text-sm">
            <div className="flex items-center gap-2 text-indigo-700 dark:text-indigo-300">
              <Sparkles size={16} />
              <span>{suggestion}</span>
            </div>
            <button 
              type="button" 
              onClick={() => {
                // Auto add revision logic could be more complex, here we just append to title for demo
                setTitle(title + " (With Reminder)");
                setSuggestion(null);
              }}
              className="text-xs font-bold uppercase text-primary underline"
            >
              Apply
            </button>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div>
            <label className="block text-sm font-semibold mb-1 text-slate-500">Priority</label>
            <select 
              className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-transparent focus:ring-2 focus:ring-primary outline-none"
              value={priority}
              onChange={(e) => setPriority(e.target.value as Priority)}
            >
              <option value={Priority.HIGH}>High</option>
              <option value={Priority.MEDIUM}>Medium</option>
              <option value={Priority.LOW}>Low</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-semibold mb-1 text-slate-500">Category</label>
            <select 
              className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-transparent focus:ring-2 focus:ring-primary outline-none"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
            >
              <option>Personal</option>
              <option>Office</option>
              <option>Study</option>
              <option>Important</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-semibold mb-1 text-slate-500">Recurrence</label>
            <select 
              className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-transparent focus:ring-2 focus:ring-primary outline-none"
              value={recurrence}
              onChange={(e) => setRecurrence(e.target.value as Recurrence)}
            >
              <option value={Recurrence.NONE}>One-time</option>
              <option value={Recurrence.DAILY}>Daily</option>
              <option value={Recurrence.WEEKLY}>Weekly</option>
              <option value={Recurrence.MONTHLY}>Monthly</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-semibold mb-1 text-slate-500">Due Date</label>
            <input 
              type="datetime-local" 
              className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-transparent focus:ring-2 focus:ring-primary outline-none"
              value={dueDate}
              onChange={(e) => setDueDate(e.target.value)}
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-semibold mb-1 text-slate-500">Tags</label>
          <div className="flex flex-wrap gap-2 mb-2">
            {tags.map(tag => (
              <span key={tag} className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 px-3 py-1 rounded-full text-sm">
                #{tag}
                <X size={14} className="cursor-pointer" onClick={() => removeTag(tag)} />
              </span>
            ))}
          </div>
          <div className="flex gap-2">
            <div className="relative flex-1">
              <TagIcon className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
              <input 
                type="text" 
                placeholder="Add tags..."
                className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-transparent focus:ring-2 focus:ring-primary outline-none"
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyDown={handleAddTag}
              />
            </div>
            <button 
              type="button" 
              onClick={() => handleAddTag()}
              className="px-4 bg-slate-100 dark:bg-slate-800 rounded-xl hover:bg-slate-200 transition-colors"
            >
              <Plus size={20} />
            </button>
          </div>
        </div>

        <div className="flex gap-3 pt-4">
          <button type="submit" className="flex-1 py-4 bg-primary text-white font-bold rounded-xl shadow-lg shadow-primary/30">
            Create Task
          </button>
          <button type="button" onClick={onCancel} className="flex-1 py-4 bg-slate-100 dark:bg-slate-800 font-bold rounded-xl">
            Cancel
          </button>
        </div>
      </form>
    </div>
  );
};

export default TaskForm;
